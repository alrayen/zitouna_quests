/**
*
* -----------------------------------------------------------------------------
*
* Template : #
* Author : #
* Author URI : #

* -----------------------------------------------------------------------------
*
**/

(function($) {
    "use strict";

    // pisticky Menu
    var header = $('.rts-header');
    var win = $(window);
    win.on('scroll', function() {
        var scroll = win.scrollTop();
        if (scroll < 100) {
           header.removeClass("rts-sticky");
        } else {
           header.addClass("rts-sticky");
        }
    });

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    //preloader
    $(window).on( 'load', function() {
        $("#rts__preloader").delay(1000).fadeOut(400);
        $("#rts__preloader").delay(1000).fadeOut(400);
    });

    // Elements Animation
    if ($('.wow').length) {
        var wow = new WOW(
            {
                boxClass: 'wow', // animated element css class (default is wow)
                animateClass: 'animated', // animation css class (default is animated)
                offset: 0, // distance to the element when triggering the animation (default is 0)
                mobile: false, // trigger animations on mobile devices (default is true)
                live: true       // act on asynchronously loaded content (default is true)
            }
        );
        wow.init();
    }
    
    //Clients Slider
    if ($('.innerpage-carousel').length) {
        $('.innerpage-carousel').slick({
            dots: true,
            infinite: true,
            speed: 500,
            slidesToShow: 5,
            slidesToScroll: 3,
            autoplay: true,
            autoplaySpeed: 1500,
            arrows: false,
            centerPadding:'160px',
            centerMode: true,
            responsive: [
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    centerMode: false,
                    centerPadding:'0px',
                    slidesToScroll: 1
                }
            },
            {
               breakpoint: 400,
                settings: {
                    arrows: false,
                    centerPadding:'0px',
                    centerMode: false,
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            ]
        });
    }

    

    $(document).ready(function(){        
        $('.accordion-list > li > .answer').hide();        
        $('.accordion-list > li').click(function() {
        if ($(this).hasClass("active")) {
          $(this).removeClass("active").find(".answer").slideUp();
        } else {
          $(".accordion-list > li.active .answer").slideUp();
          $(".accordion-list > li.active").removeClass("active");
          $(this).addClass("active").find(".answer").slideDown();
        }
        return false;
      });
      
    });

    // scrollTop init
    var pitotop = $('#rtsscrollUp'); 
    if(pitotop.length){   
        win.on('scroll', function() {
            if (win.scrollTop() > 350) {
                pitotop.fadeIn();
            } else {
                pitotop.fadeOut();
            }
        });
        pitotop.on('click', function() {
            $("html,body").animate({
                scrollTop: 0
            }, 500)
        });
    }

})(jQuery);
